// This is a manifest file that'll be compiled into including all the files listed below.
// Add new JavaScript/Coffee code in separate files in this directory and they'll automatically
// be included in the compiled file accessible from http://example.com/assets/application.js
// It's not advisable to add code directly here, but if you do, it'll appear at the bottom of the
// the compiled file.
//
//= require jquery_ujs
//= require public/jquery-application
//= require ../../../vendor/assets/javascripts/jquery.dataTables.min
//= require ../../../vendor/assets/javascripts/dataTables.filteringDelay
//= require ../../../vendor/assets/javascripts/dataTables.hiddenTitle
//= require ../../../vendor/assets/javascripts/prototype
//= require ../../../vendor/assets/javascripts/effects
//= require ../../../vendor/assets/javascripts/controls
//= require ../../../vendor/assets/javascripts/dragdrop
//= require ../../../vendor/assets/javascripts/livepipe
//= require public/proto_application
//= require public/jquery.table
//= require public/jquery.inputHint
//= require_tree ./public/

