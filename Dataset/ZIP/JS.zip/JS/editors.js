// Manifest file for including codemirror2 and jquery.wysiwyg plugins

//= require codemirror2/codemirror2
//= require codemirror2/formatting
//= require codemirror2/modes/css/css
//= require codemirror2/modes/xml/xml
//= require codemirror2/modes/javascript/javascript
//= require codemirror2/modes/htmlmixed/htmlmixed
//= require jquery.wysiwyg
//= require jquery.wysiwyg.insertContent.js