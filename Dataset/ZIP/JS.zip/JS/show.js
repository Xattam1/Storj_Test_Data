(function() {

  jQuery(function($) {
    var sortAttempts, sortCreds, sortExploits, sortVulns;
    sortCreds = function() {
      return $('#creds-table').table({
        searchInputHint: "Search credentials",
        datatableOptions: {
          "aoColumns": [
            {
              "bSortable": false
            }, null, null, null, null, null, null, null
          ],
          "oLanguage": {
            "sEmptyTable": "No tokens are associated with this Host. Click 'New Token' above to add one."
          }
        }
      });
    };
    sortVulns = function() {
      return $("#vulns-table").table({
        searchInputHint: "Search vulnerabilities",
        datatableOptions: {
          "aaSorting": [[2, 'desc']],
          "aoColumns": [
            null, {
              "bSortable": false
            }, null, {
              "bSortable": false
            }
          ],
          "oLanguage": {
            "sEmptyTable": "No vulnerabilities are associated with this Host. Click 'Add Vulnerability' above to add one."
          }
        }
      });
    };
    sortAttempts = function() {
      return $("#attempts-table").table({
        searchInputHint: "Search exploit attempts",
        datatableOptions: {
          "aaSorting": [[0, 'desc']],
          "aoColumns": [null, null, null, null, null, null],
          "oLanguage": {
            "sEmptyTable": "No exploit attempts associated with this Host."
          }
        }
      });
    };
    sortExploits = function() {
      return $("#exploits-table").table({
        searchInputHint: "Search available exploits",
        datatableOptions: {
          "aaSorting": [[0, 'desc']],
          "aoColumns": [null, null, null, null],
          "oLanguage": {
            "sEmptyTable": "No exploits have been matched with this Host."
          }
        }
      });
    };
    window.moduleLinksInit = function(moduleRunPathFragment) {
      var formId;
      formId = "#new_module_run";
      return $('a.module-name').click(function(event) {
        var modAction, pathPiece, theForm;
        if ($(this).attr('href') !== "#") {
          return true;
        } else {
          pathPiece = $(this).attr('module_fullname');
          modAction = "" + moduleRunPathFragment + pathPiece;
          theForm = $(formId);
          theForm.attr('action', modAction);
          theForm.submit();
          return false;
        }
      });
    };
    return $(document).ready(function() {
      return $("#tabs").tabs({
        selected: 0,
        spinner: 'Loading...',
        cache: true,
        load: function(e, ui) {
          $(ui.panel).find(".tab-loading").remove();
          if (!!~ui.tab.href.indexOf("vulns")) {
            sortVulns();
          }
          if (!!~ui.tab.href.indexOf("creds")) {
            sortCreds();
          }
          if (!!~ui.tab.href.indexOf("attempts")) {
            sortAttempts();
          }
          if (!!~ui.tab.href.indexOf("exploits")) {
            return sortExploits();
          }
        },
        select: function(e, ui) {
          var $panel;
          $panel = $(ui.panel);
          if ($panel.is(":empty")) {
            return $panel.append("<div class='tab-loading'></div>");
          }
        }
      });
    });
  });

}).call(this);
